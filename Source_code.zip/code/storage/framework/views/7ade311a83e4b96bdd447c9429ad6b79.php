<?php $__env->startSection('title', 'Profil szerkesztése'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-2xl mx-auto">
        <?php if(Auth::user()->is_admin): ?>
            <div class="mb-6 p-4 bg-indigo-50 border-l-4 border-indigo-400 rounded">
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="text-indigo-600 hover:text-indigo-800 font-semibold">
                    → Admin Panel
                </a>
            </div>
        <?php endif; ?>

        <div class="bg-white p-8 rounded-lg shadow">
        <h1 class="text-2xl font-bold mb-4">Profil szerkesztése</h1>

        <div class="mb-6 rounded-lg border border-indigo-100 bg-indigo-50 p-4">
            <div class="flex items-center justify-between gap-4">
                <div>
                    <h2 class="text-lg font-semibold text-gray-900">Kisállatok</h2>
                    <p class="text-sm text-gray-600">A profilodhoz tartozó kisállatok kezelése.</p>
                </div>
                <a href="<?php echo e(route('profile.pets.index')); ?>" class="inline-flex items-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700">
                    Kisállatok kezelése
                </a>
            </div>

            <?php if($user->pets->isNotEmpty()): ?>
                <div class="mt-4 grid gap-3 md:grid-cols-2">
                    <?php $__currentLoopData = $user->pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="rounded-md bg-white p-3 shadow-sm">
                            <div class="font-medium text-gray-900"><?php echo e($pet->name); ?></div>
                            <div class="text-sm text-gray-600"><?php echo e($pet->animal_type); ?> · <?php echo e($pet->breed); ?></div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>

        <?php if($errors->any()): ?>
            <div class="mb-4 bg-red-50 border-l-4 border-red-400 p-4 rounded-md">
                <ul class="list-disc ml-5 text-sm text-red-600">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(session('success')): ?>
            <div class="mb-4 bg-green-50 border-l-4 border-green-400 p-4 rounded-md">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('profile.update')); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="flex items-center gap-4">
                <div>
                    <img src="<?php echo e($user->avatar_url); ?>" alt="Avatar" class="w-24 h-24 rounded-full object-cover border" />
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Feltöltés</label>
                    <input type="file" name="avatar" accept="image/*" class="mt-1" />
                    <p class="text-xs text-gray-500 mt-1">Max 2MB. JPG, PNG, GIF, SVG.</p>
                </div>
            </div>

            <div>
                <p class="mb-2 text-sm font-medium">Vagy válassz egy alap képet</p>
                <div class="flex gap-4">
                    <label class="flex flex-col items-center text-center">
                        <input type="radio" name="avatar_choice" value="default-1" <?php echo e(old('avatar_choice', $user->avatar_choice) === 'default-1' ? 'checked' : ''); ?> />
                        <img src="<?php echo e(asset('images/avatars/default-1.svg')); ?>" class="w-16 h-16 mt-2" />
                    </label>
                    <label class="flex flex-col items-center text-center">
                        <input type="radio" name="avatar_choice" value="default-2" <?php echo e(old('avatar_choice', $user->avatar_choice) === 'default-2' ? 'checked' : ''); ?> />
                        <img src="<?php echo e(asset('images/avatars/default-2.svg')); ?>" class="w-16 h-16 mt-2" />
                    </label>
                    <label class="flex flex-col items-center text-center">
                        <input type="radio" name="avatar_choice" value="default-avatar" <?php echo e(old('avatar_choice', $user->avatar_choice) === 'default-avatar' ? 'checked' : ''); ?> />
                        <img src="<?php echo e(asset('images/avatars/default-avatar.svg')); ?>" class="w-16 h-16 mt-2" />
                    </label>
                </div>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700">Név</label>
                <input type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>" required class="mt-1 block w-full border border-gray-300 rounded-md p-2" />
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700">E-mail</label>
                <input type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" required class="mt-1 block w-full border border-gray-300 rounded-md p-2" />
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700">Új jelszó (opcionális)</label>
                <div class="password-input-wrap">
                    <input id="profile_password" type="password" name="password" class="mt-1 block w-full pr-10 border border-gray-300 rounded-md p-2" />
                    <button type="button" class="password-toggle-btn" data-target="profile_password" aria-pressed="false" title="Jelszó mutatása">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10 3C6 3 2.73 5.11 1 8c1.73 2.89 5 5 9 5s7.27-2.11 9-5c-1.73-2.89-5-5-9-5zM10 11a3 3 0 100-6 3 3 0 000 6z"/></svg>
                    </button>
                </div>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700">Jelszó megerősítése</label>
                <div class="password-input-wrap">
                    <input id="profile_password_confirmation" type="password" name="password_confirmation" class="mt-1 block w-full pr-10 border border-gray-300 rounded-md p-2" />
                    <button type="button" class="password-toggle-btn" data-target="profile_password_confirmation" aria-pressed="false" title="Jelszó mutatása">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10 3C6 3 2.73 5.11 1 8c1.73 2.89 5 5 9 5s7.27-2.11 9-5c-1.73-2.89-5-5-9-5zM10 11a3 3 0 100-6 3 3 0 000 6z"/></svg>
                    </button>
                </div>
            </div>

            <div class="flex justify-end">
                <button type="submit" class="px-4 py-2 bg-indigo-600 text-white rounded-md">Mentés</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Boss\Documents\Szakdoga\1-sprint-GRichardA\sprints\02\code\resources\views/profile/edit.blade.php ENDPATH**/ ?>