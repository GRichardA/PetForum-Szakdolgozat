<?php $__env->startSection('title', 'Események'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-6 flex justify-between items-end">
        <div>
            <h1 class="text-3xl font-bold text-gray-900">Közelgő Események</h1>
            <p class="mt-1 text-gray-500">Találkozz a helyi kutyás közösséggel!</p>
        </div>
    </div>

    
    <div class="mb-8 p-3 bg-gray-50 rounded-lg border border-gray-100 shadow-inner">
        <form method="GET" action="<?php echo e(route('events.index')); ?>" class="flex flex-col md:flex-row md:items-center gap-3">
            <div class="flex items-center gap-2 md:gap-4 w-full md:w-auto">
                <label class="text-sm text-gray-600 hidden md:block">Kategória:</label>
                <select name="category" onchange="this.form.submit()" class="border rounded px-3 py-2 text-sm">
                    <option value="" <?php echo e(request('category') ? '' : 'selected'); ?>>Összes kategória</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->slug); ?>" <?php echo e(request('category') === $category->slug ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="flex items-center gap-2 flex-1">
                <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Kulcsszó keresése címben vagy leírásban" class="flex-1 border rounded px-3 py-2 text-sm" />
                <button type="submit" class="px-4 py-2 bg-indigo-600 text-white rounded text-sm">Keresés</button>
            </div>
        </form>
    </div>
    

    
    

    
    <?php if($events->isEmpty()): ?>
        <?php
            // Dinamikus üzenet a szűrés állapotának megfelelően
            $currentCategorySlug = request()->query('category');
            $message = $currentCategorySlug ? 'Ebben a kategóriában még nincsenek események.' : 'Még nincsenek események';
            $subtext = $currentCategorySlug ? 'Próbálj más szűrőt, vagy hozz létre újat!' : 'Legyél te az első szervező!';
        ?>
        <div class="text-center py-16 bg-white rounded-lg shadow-sm border border-gray-100">
            <div class="text-6xl mb-4">🐕</div>
            <h3 class="text-lg font-medium text-gray-900"><?php echo e($message); ?></h3>
            <p class="mt-1 text-gray-500"><?php echo e($subtext); ?></p>
            <div class="mt-6">
                <?php if($currentCategorySlug): ?>
                    <a href="<?php echo e(route('events.index')); ?>" class="text-indigo-600 hover:text-indigo-500 font-medium">
                        Szűrők törlése &rarr;
                    </a>
                <?php else: ?>
                    <a href="<?php echo e(route('events.create')); ?>" class="text-indigo-600 hover:text-indigo-500 font-medium">
                        Esemény létrehozása &rarr;
                    </a>
                <?php endif; ?>
            </div>
        </div>
    
    <?php else: ?>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white overflow-hidden shadow-sm rounded-lg hover:shadow-md transition-shadow duration-300 border border-gray-100 flex flex-col h-full">
                    <div class="p-6 flex-grow">
                        <div class="flex items-center justify-between mb-4">
                            <div class="flex space-x-2">
                                
                                <span class="px-2 py-1 text-xs font-semibold bg-indigo-100 text-indigo-800 rounded-full">
                                    Esemény
                                </span>
                                
                                
                                <?php if($event->category): ?>
                                    <span class="px-2 py-1 text-xs font-semibold rounded-full text-white"
                                        style="background-color: <?php echo e($event->category->color_code ?? '#6b7280'); ?>;">
                                        <?php echo e($event->category->name); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            
                            
                            <span class="text-sm text-gray-500">
                                <?php echo e(\Carbon\Carbon::parse($event->event_date)->format('Y.m.d H:i')); ?>

                            </span>
                        </div>
                        <h3 class="text-xl font-bold text-gray-900 mb-2">
                            <a href="<?php echo e(route('events.show', $event->id)); ?>" class="hover:underline"><?php echo e($event->title); ?></a>
                        </h3>
                        <p class="text-gray-600 text-sm mb-4 flex items-center">
                            📍 <?php echo e($event->location); ?>

                        </p>
                        <p class="text-gray-500 text-sm line-clamp-3">
                            <?php echo e($event->description ?? 'Nincs leírás megadva.'); ?>

                        </p>
                    </div>
                    
                    
                    <div class="bg-gray-50 px-6 py-4 border-t border-gray-100 flex justify-between items-center">
                        <a href="<?php echo e(route('events.show', $event->id)); ?>" class="text-sm text-indigo-600 hover:text-indigo-900 font-medium">Megnyitás</a>

                        <?php if(Auth::id() === $event->user_id): ?>
                            <div class="flex items-center space-x-4">
                                <a href="<?php echo e(route('events.edit', $event->id)); ?>" class="text-sm text-indigo-600 hover:text-indigo-900 font-medium">Szerkesztés</a>
                                <form action="<?php echo e(route('events.destroy', $event->id)); ?>" method="POST" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" onclick="return confirm('Biztosan törölni akarod?')" class="text-sm text-red-600 hover:text-red-900 font-medium">Törlés</button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Boss\Documents\Szakdoga\1-sprint-GRichardA\sprints\02\code\resources\views/events/index.blade.php ENDPATH**/ ?>