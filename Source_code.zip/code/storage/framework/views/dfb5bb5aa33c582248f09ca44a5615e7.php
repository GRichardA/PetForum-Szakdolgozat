<?php $__env->startSection('title', 'Esemény Szerkesztése'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-3xl font-bold text-gray-900 mb-6">Esemény Szerkesztése: <span class="text-indigo-600"><?php echo e($event->title); ?></span></h1>

    <div class="bg-white p-8 rounded-lg shadow-xl border border-gray-100">
        <a href="<?php echo e(route('events.index')); ?>" class="text-indigo-600 hover:text-indigo-500 font-medium mb-6 inline-block">
            &larr; Vissza a listához
        </a>

        <?php if($errors->any()): ?>
            <div class="mb-4 bg-red-50 border-l-4 border-red-400 p-4 rounded-md">
                <p class="font-bold text-red-700">Hiba történt a frissítés során:</p>
                <ul class="list-disc ml-5 text-sm text-red-600 mt-2">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('events.update', $event->id)); ?>" method="POST" class="space-y-6">
            <?php echo csrf_field(); ?> 
            <?php echo method_field('PUT'); ?> 

            <div>
                <label for="title" class="block text-sm font-medium text-gray-700 mb-1">Esemény címe:</label>
                <input type="text" name="title" id="title" required 
                       value="<?php echo e(old('title', $event->title)); ?>"
                       class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 p-2.5">
            </div>

            <div>
                <label for="category_id" class="block text-sm font-medium text-gray-700 mb-1">Kategória:</label>
                <select name="category_id" id="category_id" required 
                        class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 p-2.5">
                    <option value="">Válassz kategóriát</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <option value="<?php echo e($category->id); ?>"
                            <?php if(old('category_id', $event->category_id) == $category->id): ?>
                                selected
                            <?php endif; ?>
                        >
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label for="event_date" class="block text-sm font-medium text-gray-700 mb-1">Dátum és Idő:</label>
                <input type="datetime-local" name="event_date" id="event_date" required 
                       value="<?php echo e(old('event_date', \Carbon\Carbon::parse($event->event_date)->format('Y-m-d\TH:i'))); ?>"
                       class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 p-2.5">
            </div>

            <div>
                <label for="location" class="block text-sm font-medium text-gray-700 mb-1">Helyszín:</label>
                <input type="text" name="location" id="location" required 
                       value="<?php echo e(old('location', $event->location)); ?>"
                       class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 p-2.5">
            </div>

            <div>
                <label for="description" class="block text-sm font-medium text-gray-700 mb-1">Leírás (opcionális):</label>
                <textarea name="description" id="description" rows="4" 
                          class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 p-2.5 resize-y"><?php echo e(old('description', $event->description)); ?></textarea>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label for="allowed_animal_types" class="block text-sm font-medium text-gray-700 mb-1">Elfogadott állattípusok</label>
                    <textarea name="allowed_animal_types" id="allowed_animal_types" rows="4" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 p-2.5 resize-y" placeholder="kutya\nmacska"><?php echo e(old('allowed_animal_types', implode("\n", $event->allowed_animal_types ?? []))); ?></textarea>
                    <p class="mt-1 text-xs text-gray-500">Egy sorba egy típus kerüljön.</p>
                </div>

                <div>
                    <label for="allowed_breeds" class="block text-sm font-medium text-gray-700 mb-1">Elfogadott fajták</label>
                    <textarea name="allowed_breeds" id="allowed_breeds" rows="4" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 p-2.5 resize-y" placeholder="német juhász\nlabrador"><?php echo e(old('allowed_breeds', implode("\n", $event->allowed_breeds ?? []))); ?></textarea>
                    <p class="mt-1 text-xs text-gray-500">Egy sorba egy fajta kerüljön.</p>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 items-end">
                <label class="flex items-center gap-3 rounded-md border border-gray-300 p-3">
                    <input type="checkbox" name="vaccination_required" value="1" <?php echo e(old('vaccination_required', $event->vaccination_required) ? 'checked' : ''); ?>>
                    <span class="text-sm font-medium text-gray-700">Kötelező oltás</span>
                </label>

                <div>
                    <label for="capacity" class="block text-sm font-medium text-gray-700 mb-1">Kapacitás</label>
                    <input type="number" min="1" name="capacity" id="capacity" value="<?php echo e(old('capacity', $event->capacity)); ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 p-2.5">
                </div>
            </div>

            <div>
                <button type="submit" class="w-full inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150 ease-in-out">
                    Esemény Frissítése
                </button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Boss\Documents\Szakdoga\1-sprint-GRichardA\sprints\02\code\resources\views/events/edit.blade.php ENDPATH**/ ?>