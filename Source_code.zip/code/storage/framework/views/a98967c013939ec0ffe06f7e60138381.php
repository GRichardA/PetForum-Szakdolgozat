<?php $__env->startSection('title', $event->title); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-xl border border-gray-100">
        
        <a href="<?php echo e(route('events.index')); ?>" class="text-indigo-600 hover:text-indigo-500 font-medium mb-6 inline-block">
            &larr; Vissza az eseményekhez
        </a>
        
        
        <div class="flex justify-between items-start mb-6 border-b pb-4">
            <h1 class="text-4xl font-extrabold text-gray-900 leading-tight pr-4"><?php echo e($event->title); ?></h1>
            
            
            <span style="background-color: <?php echo e($event->category->color_code ?? '#6b7280'); ?>" 
                  class="text-white text-sm font-semibold px-3 py-1.5 rounded-full shadow-md whitespace-nowrap">
                <?php echo e($event->category->name); ?>

            </span>
        </div>

        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-y-6 gap-x-10 mb-8">
            
            <div>
                <p class="text-sm font-medium text-gray-500 uppercase tracking-wider">Dátum és Idő</p>
                <p class="mt-1 text-lg font-semibold text-gray-800">
                    <?php echo e(\Carbon\Carbon::parse($event->event_date)->isoFormat('YYYY. MMMM D. (dddd) HH:mm')); ?>

                </p>
            </div>
            
            
            <div>
                <p class="text-sm font-medium text-gray-500 uppercase tracking-wider">Helyszín</p>
                <p class="mt-1 text-lg font-semibold text-gray-800"><?php echo e($event->location); ?></p>
            </div>
            
            
            <div>
                <p class="text-sm font-medium text-gray-500 uppercase tracking-wider">Létrehozta</p>
                <p class="mt-1 text-lg text-gray-800"><?php echo e($event->user->name ?? 'Ismeretlen felhasználó'); ?></p>
            </div>

            
            <?php if(auth()->guard()->check()): ?>
                <?php if($event->user_id === Auth::id()): ?>
                    <div class="flex space-x-4 mt-6 md:mt-0 items-center justify-start md:justify-end">
                        <a href="<?php echo e(route('events.edit', $event->id)); ?>" 
                           class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 shadow-sm transition duration-150">
                            Szerkesztés
                        </a>
                        
                        
                        <form action="<?php echo e(route('events.destroy', $event->id)); ?>" method="POST" onsubmit="return confirm('Biztosan törölni szeretné ezt az eseményt? A művelet visszavonhatatlan!');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" 
                                    class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 shadow-sm transition duration-150">
                                Törlés
                            </button>
                        </form>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div class="rounded-lg border border-gray-200 bg-gray-50 p-4">
                <h2 class="text-lg font-bold text-gray-900 mb-3">Pet-feltételek</h2>
                <p class="text-sm text-gray-600 mb-2">Elfogadott állattípusok:</p>
                <div class="flex flex-wrap gap-2 mb-4">
                    <?php $__empty_1 = true; $__currentLoopData = $event->allowed_animal_types ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <span class="rounded-full bg-indigo-100 px-3 py-1 text-sm text-indigo-700"><?php echo e($type); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <span class="text-sm text-gray-500">Nincs megadott korlátozás.</span>
                    <?php endif; ?>
                </div>

                <p class="text-sm text-gray-600 mb-2">Elfogadott fajták:</p>
                <div class="flex flex-wrap gap-2 mb-4">
                    <?php $__empty_1 = true; $__currentLoopData = $event->allowed_breeds ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <span class="rounded-full bg-emerald-100 px-3 py-1 text-sm text-emerald-700"><?php echo e($breed); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <span class="text-sm text-gray-500">Nincs megadott korlátozás.</span>
                    <?php endif; ?>
                </div>

                <div class="text-sm text-gray-700 space-y-1">
                    <p>Oltás szükséges: <strong><?php echo e($event->vaccination_required ? 'igen' : 'nem'); ?></strong></p>
                    <p>Kapacitás: <strong><?php echo e($event->capacity ?? 'nincs megadva'); ?></strong></p>
                    <p>Jelentkezések száma: <strong><?php echo e($event->confirmedRegistrations->count()); ?></strong></p>
                    <?php if($event->capacity !== null): ?>
                        <p>Szabad hely: <strong><?php echo e($event->availableSpots()); ?></strong></p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="rounded-lg border border-gray-200 bg-white p-4">
                <h2 class="text-lg font-bold text-gray-900 mb-3">Jelentkezés kisállattal</h2>

                <?php if(auth()->guard()->check()): ?>
                    <?php if($userPets->isEmpty()): ?>
                        <p class="text-sm text-gray-600 mb-3">Még nincs felvett kisállatod.</p>
                        <a href="<?php echo e(route('profile.pets.create')); ?>" class="inline-flex items-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700">Kisállat felvétele</a>
                    <?php else: ?>
                        <?php if($event->isFull()): ?>
                            <div class="mb-4 rounded-md bg-red-50 p-3 text-sm text-red-700">Az esemény betelt.</div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('events.registrations.store', $event)); ?>" method="POST" class="space-y-4">
                            <?php echo csrf_field(); ?>
                            <div>
                                <label for="pet_id" class="block text-sm font-medium text-gray-700 mb-1">Válassz kisállatot</label>
                                <select name="pet_id" id="pet_id" class="block w-full rounded-md border border-gray-300 p-2.5">
                                    <option value="">Válassz...</option>
                                    <?php $__currentLoopData = $userPets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($pet->id); ?>"><?php echo e($pet->name); ?> (<?php echo e($pet->animal_type); ?>, <?php echo e($pet->breed); ?>)</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['pet_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <button type="submit" class="inline-flex items-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:cursor-not-allowed disabled:bg-gray-400" <?php echo e($event->isFull() ? 'disabled' : ''); ?>>
                                Jelentkezés
                            </button>
                        </form>
                    <?php endif; ?>

                    <?php if($myRegistrations->isNotEmpty()): ?>
                        <div class="mt-6 border-t pt-4">
                            <h3 class="text-sm font-semibold text-gray-900 mb-3">A te jelentkezéseid</h3>
                            <div class="space-y-3">
                                <?php $__currentLoopData = $myRegistrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="flex items-center justify-between rounded-md bg-gray-50 p-3">
                                        <div>
                                            <div class="font-medium text-gray-900"><?php echo e($registration->pet->name); ?></div>
                                            <div class="text-sm text-gray-600"><?php echo e($registration->pet->animal_type); ?> · <?php echo e($registration->pet->breed); ?></div>
                                        </div>
                                        <form action="<?php echo e(route('events.registrations.destroy', [$event, $registration])); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="text-sm font-medium text-red-600 hover:text-red-700">Leiratkozás</button>
                                        </form>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <p class="text-sm text-gray-600">Jelentkezéshez be kell jelentkezned.</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="rounded-lg border border-gray-200 bg-white p-4 mb-8">
            <h2 class="text-lg font-bold text-gray-900 mb-3">Résztvevő kisállatok</h2>
            <div class="grid gap-3 md:grid-cols-2">
                <?php $__empty_1 = true; $__currentLoopData = $event->registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="rounded-md bg-gray-50 p-3">
                        <div class="font-medium text-gray-900"><?php echo e($registration->pet->name); ?></div>
                        <div class="text-sm text-gray-600"><?php echo e($registration->pet->animal_type); ?> · <?php echo e($registration->pet->breed); ?></div>
                        <div class="text-xs text-gray-500">Gazdi: <?php echo e($registration->user->name); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-sm text-gray-600">Még nincs jelentkező.</p>
                <?php endif; ?>
            </div>
        </div>

        
        <div class="pt-6 border-t mt-6">
            <h2 class="text-xl font-bold text-gray-900 mb-3">Részletes Leírás</h2>
            <div class="text-gray-700 leading-relaxed space-y-4">
                
                <p><?php echo nl2br(e($event->description)); ?></p>
            </div>
        </div>
        
        
        <div class="max-w-4xl mx-auto bg-white p-6 rounded-lg shadow mt-6 border border-gray-100">
            <h3 class="text-lg font-bold mb-4">Hozzászólások</h3>

            <?php if(auth()->guard()->check()): ?>
                <form action="<?php echo e(route('events.comments.store', $event->id)); ?>" method="POST" class="mb-4">
                    <?php echo csrf_field(); ?>
                    <textarea name="body" rows="3" class="w-full border rounded p-3" placeholder="Írj hozzászólást..."></textarea>
                    <div class="mt-2 text-right">
                        <button type="submit" class="px-4 py-2 bg-indigo-600 text-white rounded">Hozzászólás</button>
                    </div>
                </form>
            <?php else: ?>
                <p class="text-sm text-gray-600 mb-4">Jelentkezz be a hozzászóláshoz.</p>
            <?php endif; ?>

            <div>
                <?php $__empty_1 = true; $__currentLoopData = $event->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo $__env->make('events._comment', ['comment' => $comment], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-sm text-gray-600">Még nincs hozzászólás.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Boss\Documents\Szakdoga\1-sprint-GRichardA\sprints\02\code\resources\views/events/show.blade.php ENDPATH**/ ?>