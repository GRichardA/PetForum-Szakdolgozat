<div class="flex items-start space-x-4 py-4 border-b">
    <div class="flex-shrink-0">
        <img src="<?php echo e($comment->user->avatar_url); ?>" alt="<?php echo e($comment->user->name); ?>" class="w-10 h-10 rounded-full object-cover" />
    </div>
    <div class="flex-1">
        <div class="flex items-center justify-between">
            <div class="text-sm font-semibold text-gray-800"><?php echo e($comment->user->name); ?></div>
            <div class="flex items-center space-x-4">
                <div class="text-xs text-gray-500"><?php echo e($comment->created_at->diffForHumans()); ?></div>
                
                
                <?php if(auth()->guard()->check()): ?>
                    <?php if($comment->canBeDeletedBy(Auth::user())): ?>
                        <form action="<?php echo e(route('events.comments.destroy', [$comment->event_id, $comment->id])); ?>" method="POST" class="inline" onsubmit="return confirm('Biztosan törli ezt a hozzászólást?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-xs text-red-600 hover:text-red-800 hover:underline">Törlés</button>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="mt-2 text-gray-700"><?php echo nl2br(e($comment->body)); ?></div>

        
        <?php if(auth()->guard()->check()): ?>
            <div class="mt-2">
                <button type="button" class="text-xs text-indigo-600 hover:underline" onclick="document.getElementById('reply-form-<?php echo e($comment->id); ?>').classList.toggle('hidden')">Válasz</button>

                <form id="reply-form-<?php echo e($comment->id); ?>" action="<?php echo e(route('events.comments.store', $comment->event_id)); ?>" method="POST" class="mt-2 hidden">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="parent_id" value="<?php echo e($comment->id); ?>" />
                    <textarea name="body" rows="2" class="w-full border rounded p-2 text-sm" placeholder="Írj választ..."></textarea>
                    <div class="mt-2 text-right">
                        <button type="submit" class="px-3 py-1 bg-indigo-600 text-white rounded text-sm">Küldés</button>
                    </div>
                </form>
            </div>
        <?php endif; ?>

        <?php if($comment->children->count()): ?>
            <div class="mt-4 border-l pl-4">
                <?php $__currentLoopData = $comment->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('events._comment', ['comment' => $child], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\Boss\Documents\Szakdoga\1-sprint-GRichardA\sprints\02\code\resources\views/events/_comment.blade.php ENDPATH**/ ?>