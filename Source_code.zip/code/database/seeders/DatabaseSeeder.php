<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        $this->call([UserSeeder::class]);
        $this->call([AdminUserSeeder::class]);
        $this->call([CategorySeeder::class]);
        $this->call([EventSeeder::class]);
        $this->call([PetSeeder::class]);
        $this->call([RegistrationSeeder::class]);
        $this->call([CommentSeeder::class]);
    }
}
